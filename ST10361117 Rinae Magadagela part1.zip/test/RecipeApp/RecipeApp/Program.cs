﻿using System;

namespace RecipeApp
{
    class Recipe
    {
        private string[] ingredients;
        private string[] steps;

        public Recipe()
        {
            // Initialize arrays with default size
            ingredients = new string[0];
            steps = new string[0];
        }

        public void AddIngredients(int count)
        {
            ingredients = new string[count];
            for (int i = 0; i < count; i++)
            {
                Console.Write($"Enter name of ingredient {i + 1}: ");
                string name = Console.ReadLine();
                if (int.TryParse(name, out _))
                {
                    Console.WriteLine("Please enter a valid ingredient name.");
                    //  statement here to skip the rest of the loop iteration.
                    
                    continue;
                   
                }
                Console.Write($"Enter quantity for {name}: ");
                string quantity = Console.ReadLine();
                Console.Write($"Enter unit of measurement for {name}: ");
                string unit = Console.ReadLine();
                ingredients[i] = $"{quantity} {unit} of {name}";
            }
        }

        public void AddSteps(int count)
        {
            steps = new string[count];
            for (int i = 0; i < count; i++)
            {
                Console.Write($"Enter step {i + 1} description: ");
                steps[i] = Console.ReadLine();
            }
        }

        public void DisplayRecipe()
        {
            Console.WriteLine("\nRecipe:");
            Console.WriteLine("Ingredients:");
            foreach (string ingredient in ingredients)
            {
                Console.WriteLine(" " + ingredient);
            }
            Console.WriteLine("\nSteps:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i]}");
            }
        }

        public void ScaleRecipe(double factor)
        {
            for (int i = 0; i < ingredients.Length; i++)
            {
                string[] parts = ingredients[i].Split(' ');
                double quantity = double.Parse(parts[0]);
                quantity *= factor;
                ingredients[i] = $"{quantity} {parts[1]} of {parts[4]}";
            }
        }

        public void ClearRecipe()
        {
            ingredients = new string[0];
            steps = new string[0];
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();

            Console.Write("Enter number of ingredients: ");
            int ingredientCount = int.Parse(Console.ReadLine());
            recipe.AddIngredients(ingredientCount);

            Console.Write("Enter number of steps: ");
            int stepCount = int.Parse(Console.ReadLine());
            recipe.AddSteps(stepCount);

            recipe.DisplayRecipe();

            Console.Write("Enter scaling factor (0.5, 2, or 3): ");
            double factor = double.Parse(Console.ReadLine());
            recipe.ScaleRecipe(factor);

            recipe.DisplayRecipe();

            // Additional functionalities like clearing recipe can be implemented as per requirement
        }
    }
}
